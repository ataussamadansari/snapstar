class UserModel {
  final String id;
  final String name;
  final String username;
  final String email;
  final String? phone;
  final String? avatarUrl;
  final String? bio;
  final String? role;
  final bool isAnonymous;

  final int postsCount;
  final int subscriberCount;
  final int subscribingCount;

  final DateTime createdAt;
  final DateTime updatedAt;

  UserModel({
    required this.id,
    required this.name,
    required this.username,
    required this.email,
    this.phone,
    this.avatarUrl,
    this.bio,
    this.role,
    this.isAnonymous = false,
    required this.postsCount,
    required this.subscriberCount,
    required this.subscribingCount,
    required this.createdAt,
    required this.updatedAt,
  });

  factory UserModel.fromJson(Map<String, dynamic> json) {
    return UserModel(
      id: json['id'] ?? '',
      name: json['name'] ?? '',
      username: json['username'] ?? '',
      email: json['email'] ?? '',
      phone: json['phone'],
      avatarUrl: json['avatar_url'],
      bio: json['bio'],
      role: json['role'],
      isAnonymous: json['is_anonymous'] == true,
      postsCount: json['posts_count'] ?? 0,
      subscriberCount: json['subscriber_count'] ?? 0,
      subscribingCount: json['subscribing_count'] ?? 0,
      createdAt: json['created_at'] != null
          ? DateTime.parse(json['created_at'])
          : DateTime.now(),
      updatedAt: json['updated_at'] != null
          ? DateTime.parse(json['updated_at'])
          : DateTime.now(),
    );
  }

  Map<String, dynamic> toJson() {
    final normalizedEmail = email.trim().isEmpty ? null : email.trim();

    return {
      'id': id,
      'name': name,
      'username': username,
      'email': normalizedEmail,
      'phone': phone,
      'avatar_url': avatarUrl,
      'bio': bio,
      'role': role,
      'is_anonymous': isAnonymous,
      'posts_count': postsCount,
      'subscriber_count': subscriberCount,
      'subscribing_count': subscribingCount,
      'created_at': createdAt.toIso8601String(),
      'updated_at': updatedAt.toIso8601String(),
    };
  }
}
