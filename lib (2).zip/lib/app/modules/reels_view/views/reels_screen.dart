import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:hugeicons/hugeicons.dart';

import '../../../core/utils/date_time_extension.dart';
import '../../../core/utils/number_formatter.dart';
import '../../../data/controllers/comment_controller.dart';
import '../../../data/controllers/global_media_controller.dart';
import '../../../data/controllers/like_controller.dart';
import '../../../data/controllers/share_controller.dart';
import '../../../data/models/post_model.dart';
import '../../../data/repositories/auth_repository.dart';
import '../../../global_widgets/app_avatar.dart';
import '../../../global_widgets/auto_play_video.dart';
import '../../../global_widgets/app_cached_image.dart';
import '../../../global_widgets/comment_bottom_sheet.dart';
import '../../../global_widgets/loading_skeleton.dart';
import '../../../global_widgets/share_post_bottom_sheet.dart';
import '../../../global_widgets/subscribe_button.dart';
import '../../main_view/controllers/main_controller.dart';
import '../../../routes/app_routes.dart';
import '../controllers/reels_controller.dart';

class ReelsScreen extends StatefulWidget {
  const ReelsScreen({super.key});

  @override
  State<ReelsScreen> createState() => _ReelsScreenState();
}

class _ReelsScreenState extends State<ReelsScreen> {
  late final ReelsController _controller;
  late final MainController _mainController;

  @override
  void initState() {
    super.initState();
    _controller = Get.find<ReelsController>();
    _mainController = Get.find<MainController>();
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Obx(() {
        final isReelsScreenActive = _mainController.currentIndex.value == 3;
        final activeReelIndex = _controller.currentPage.value;

        if (_controller.isLoading.value && _controller.reels.isEmpty) {
          return const ReelsSkeleton();
        }

        if (_controller.reels.isEmpty) {
          return RefreshIndicator(
            onRefresh: _controller.refreshReels,
            child: SafeArea(
              child: ListView(
                physics: const AlwaysScrollableScrollPhysics(),
                children: const [
                  SizedBox(height: 160),
                  Center(
                    child: Text(
                      'No reels available right now',
                      style: TextStyle(color: Colors.white),
                    ),
                  ),
                  SizedBox(height: 24),
                ],
              ),
            ),
          );
        }

        return Stack(
          children: [
            RefreshIndicator(
              onRefresh: _controller.refreshReels,
              child: PageView.builder(
                controller: _controller.pageController,
                physics: const AlwaysScrollableScrollPhysics(
                  parent: PageScrollPhysics(),
                ),
                scrollDirection: Axis.vertical,
                onPageChanged: (index) {
                  _controller.onPageChanged(index);
                },
                itemCount: _controller.reels.length,
                itemBuilder: (context, index) {
                  return _ReelView(
                    key: ValueKey(_controller.reels[index].id),
                    post: _controller.reels[index],
                    isActive: index == activeReelIndex,
                    isScreenActive: isReelsScreenActive,
                  );
                },
              ),
            ),
            if (_controller.isLoadingMore.value)
              Positioned(
                left: 0,
                right: 0,
                bottom: 0,
                child: const SafeArea(
                  top: false,
                  minimum: EdgeInsets.only(bottom: 24),
                  child: Center(
                    child: CircularProgressIndicator(strokeWidth: 2),
                  ),
                ),
              ),
          ],
        );
      }),
    );
  }
}

class _ReelView extends StatefulWidget {
  const _ReelView({
    super.key,
    required this.post,
    required this.isActive,
    required this.isScreenActive,
  });

  final PostModel post;
  final bool isActive;
  final bool isScreenActive;

  @override
  State<_ReelView> createState() => _ReelViewState();
}

class _ReelViewState extends State<_ReelView>
    with AutomaticKeepAliveClientMixin {
  final _likeController = Get.find<LikeController>();
  final _commentController = Get.find<CommentController>();
  final _shareController = Get.find<ShareController>();
  final _mediaController = Get.find<GlobalMediaController>();
  final _authRepo = Get.find<AuthRepository>();

  late PostModel _post;

  bool _isCaptionExpanded = false;

  @override
  bool get wantKeepAlive => true;

  @override
  void initState() {
    super.initState();
    _post = widget.post;

    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      _likeController.initializePost(_post.id, _post.likeCount);
      _commentController.initializePost(_post.id, _post.commentCount);
      _shareController.initializePost(_post.id, _post.shareCount);
    });
  }

  @override
  void didUpdateWidget(covariant _ReelView oldWidget) {
    super.didUpdateWidget(oldWidget);
    _post = widget.post;

    if (oldWidget.post.id != widget.post.id) {
      _isCaptionExpanded = false;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (!mounted) return;
        _likeController.initializePost(_post.id, _post.likeCount);
        _commentController.initializePost(_post.id, _post.commentCount);
        _shareController.initializePost(_post.id, _post.shareCount);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);

    final user = _post.user;
    final caption = _post.caption.trim();
    final hasCaption = caption.isNotEmpty;
    final avatarUrl = user?.avatarUrl;
    final myId = _authRepo.currentUserId;
    final userId = user?.id;

    return Stack(
      fit: StackFit.expand,
      children: [
        GestureDetector(
          onDoubleTap: () {
            if (!_likeController.isLiked(_post.id)) {
              _likeController.toggleLike(_post.id);
            }
          },
          child: _buildReelMedia(),
        ),
        const DecoratedBox(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                Colors.black45,
                Colors.transparent,
                Colors.transparent,
                Colors.black54,
              ],
            ),
          ),
        ),
        SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(12, 10, 12, 16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildTopBar(),
                const Spacer(),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Expanded(
                                child: GestureDetector(
                                  behavior: HitTestBehavior.opaque,
                                  onTap: user?.id == null
                                      ? null
                                      : () => Get.toNamed(
                                          Routes.userProfile,
                                          arguments: user!.id,
                                        ),
                                  child: Row(
                                    children: [
                                      AppAvatar(
                                        radius: 16,
                                        avatarUrl: avatarUrl,
                                        backgroundColor: Colors.grey.shade800,
                                        iconColor: Colors.white,
                                        iconSize: 18,
                                      ),
                                      const SizedBox(width: 10),
                                      Expanded(
                                        child: Text(
                                          '@${user?.username ?? 'snapstar'}',
                                          maxLines: 1,
                                          overflow: TextOverflow.ellipsis,
                                          style: const TextStyle(
                                            color: Colors.white,
                                            fontWeight: FontWeight.w700,
                                            fontSize: 15,
                                          ),
                                        ),
                                      ),
                                      if (userId != null && userId != myId) ...[
                                        const SizedBox(width: 8),
                                        SizedBox(
                                          width: 118,
                                          child: SubscriberButton(
                                            userId: userId,
                                            fullWidth: true,
                                            height: 32,
                                            borderRadius: 9,
                                            fontSize: 12,
                                            horizontalPadding:
                                                const EdgeInsets.symmetric(
                                                  horizontal: 8,
                                                ),
                                          ),
                                        ),
                                      ],
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                          if (hasCaption) ...[
                            const SizedBox(height: 10),
                            _buildCaption(caption),
                          ],
                          const SizedBox(height: 6),
                          Text(
                            _post.createdAt.timeAgo,
                            style: TextStyle(
                              color: Colors.white.withValues(alpha: 0.75),
                              fontSize: 12,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 8),
                    _buildActionColumn(),
                  ],
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildTopBar() {
    final reelsController = Get.find<ReelsController>();

    return Row(
      children: [
        const Text(
          'Reels',
          style: TextStyle(
            color: Colors.white,
            fontSize: 22,
            fontWeight: FontWeight.w700,
          ),
        ),
        const Spacer(),
        IconButton(
          onPressed: reelsController.refreshReels,
          icon: const Icon(Icons.refresh_rounded, color: Colors.white),
        ),
        Obx(
          () => IconButton(
            onPressed: _mediaController.toggleMute,
            icon: Icon(
              _mediaController.isMuted.value
                  ? Icons.volume_off_rounded
                  : Icons.volume_up_rounded,
              color: Colors.white,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildReelMedia() {
    if (_post.mediaUrls.isEmpty) {
      return const SizedBox.shrink();
    }

    final shouldPlay = widget.isScreenActive && widget.isActive;

    if (!shouldPlay) {
      final thumbnailUrl = _post.thumbnailUrls.isNotEmpty
          ? _post.thumbnailUrls.first
          : null;

      if (thumbnailUrl != null && thumbnailUrl.isNotEmpty) {
        return AppCachedImage(imageUrl: thumbnailUrl, fit: BoxFit.cover);
      }

      return const ColoredBox(color: Colors.black);
    }

    return Obx(
      () => AutoPlayVideo(
        videoUrl: _post.mediaUrls.first,
        videoId: _post.id,
        isMuted: _mediaController.isMuted.value,
        isActive: true,
        respectVisibility: false,
        enforceSinglePlayback: false,
        keepAlive: false,
      ),
    );
  }

  Widget _buildActionColumn() {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Obx(
          () => _ActionButton(
            icon: _likeController.isLiked(_post.id)
                ? Icons.favorite
                : Icons.favorite_border,
            color: _likeController.isLiked(_post.id)
                ? Colors.redAccent
                : Colors.white,
            count: NumberFormatter.format(_likeController.likeCount(_post.id)),
            onTap: () => _likeController.toggleLike(_post.id),
          ),
        ),
        const SizedBox(height: 18),
        Obx(
          () => _ActionButton(
            hugeIcon: HugeIcons.strokeRoundedComment03,
            count: NumberFormatter.format(
              _commentController.commentCount(_post.id),
            ),
            onTap: () {
              showModalBottomSheet(
                context: context,
                isScrollControlled: true,
                useSafeArea: true,
                backgroundColor: Colors.transparent,
                builder: (_) => CommentBottomSheet(postId: _post.id),
              );
            },
          ),
        ),
        const SizedBox(height: 18),
        Obx(() {
          final shareCount = _shareController.shareCount(_post.id);
          return _ActionButton(
            hugeIcon: HugeIcons.strokeRoundedShare01,
            color: _shareController.isSharing(_post.id)
                ? Colors.lightBlueAccent
                : Colors.white,
            count: shareCount > 0 ? NumberFormatter.format(shareCount) : null,
            onTap: () {
              showModalBottomSheet(
                context: context,
                isScrollControlled: true,
                useSafeArea: true,
                backgroundColor: Colors.transparent,
                builder: (_) => SharePostBottomSheet(post: _post),
              );
            },
          );
        }),
        const SizedBox(height: 18),
        Container(
          width: 30,
          height: 30,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(6),
            border: Border.all(color: Colors.white70),
            image: _post.thumbnailUrls.isNotEmpty
                ? DecorationImage(
                    image: CachedNetworkImageProvider(
                      _post.thumbnailUrls.first,
                    ),
                    fit: BoxFit.cover,
                  )
                : null,
          ),
          child: _post.thumbnailUrls.isEmpty
              ? const Icon(
                  Icons.music_note_rounded,
                  color: Colors.white,
                  size: 18,
                )
              : null,
        ),
      ],
    );
  }

  Widget _buildCaption(String caption) {
    const minExpandableLength = 85;
    final canExpand = caption.length > minExpandableLength;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          caption,
          maxLines: _isCaptionExpanded ? 8 : 2,
          overflow: _isCaptionExpanded
              ? TextOverflow.visible
              : TextOverflow.ellipsis,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 13,
            height: 1.3,
          ),
        ),
        if (canExpand)
          GestureDetector(
            onTap: () {
              setState(() {
                _isCaptionExpanded = !_isCaptionExpanded;
              });
            },
            child: Padding(
              padding: const EdgeInsets.only(top: 2),
              child: Text(
                _isCaptionExpanded ? 'See less' : 'See more',
                style: TextStyle(
                  color: Colors.white.withValues(alpha: 0.85),
                  fontSize: 12,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
          ),
      ],
    );
  }
}

class _ActionButton extends StatelessWidget {
  const _ActionButton({
    this.icon,
    this.hugeIcon,
    this.count,
    this.color = Colors.white,
    this.onTap,
  });

  final IconData? icon;
  final List<List<dynamic>>? hugeIcon;
  final String? count;
  final Color color;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: Column(
        children: [
          if (icon != null) Icon(icon, color: color, size: 30),
          if (icon == null && hugeIcon != null)
            HugeIcon(icon: hugeIcon!, color: color, size: 30),
          if (count != null) ...[
            const SizedBox(height: 4),
            Text(
              count!,
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.w700,
                fontSize: 12,
              ),
            ),
          ],
        ],
      ),
    );
  }
}
